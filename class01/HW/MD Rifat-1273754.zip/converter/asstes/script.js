let mile =document.querySelector("#mile")
let km =document.querySelector("#km")
let btn1 =document.querySelector("#btn1")

let inch =document.querySelector("#inch")
let cm =document.querySelector("#cm")
let btn2 =document.querySelector("#btn2")

let inch2 =document.querySelector("#inch2")
let feet =document.querySelector("#feet")
let btn3 =document.querySelector("#btn3")

let fahrenheit =document.querySelector("#fahrenheit")
let Celsius =document.querySelector("#Celsius")
let btn4 =document.querySelector("#btn4")

// ============= btn1 =========
btn1.addEventListener("click",function(){
   let a= Number(mile.value) 
    km.value= (a*1.60934)
})

// =========== btn2========== 
btn2.addEventListener("click",function(){
   let b= Number(inch.value) 
    cm.value= (b*2.54)
})

// =========== btn3========== 
btn3.addEventListener("click",function(){
   let c= Number(feet.value)
    inch2.value= (c*12)
})

// =========== btn4========== 
btn4.addEventListener("click",function(){
   let d= Number(Celsius.value)
   fahrenheit.value= (d*(9/5)+32)
})